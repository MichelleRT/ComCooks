# Define your tables below (or better in another model file) for example
#
# >>> db.define_table('mytable', Field('myfield', 'string'))
#
# Fields can be 'string','text','password','integer','double','boolean'
#       'date','time','datetime','blob','upload', 'reference TABLENAME'
# There is an implicit 'id integer autoincrement' field
# Consult manual for more options, validators, etc.
from datetime import datetime

def get_first_name():
    first_name = 'anonymous'
    if auth.user:
        first_name = auth.user.first_name
    return first_name

db.define_table('post',
				Field('contents', 'text'),
				Field('author', 'string'),
				Field('user_id', db.auth_user),
				Field('post_time', 'datetime'),
				Field('thumbs_up_count', 'integer'),
				Field('thumbs_down_count', 'integer'),
				Field('thumbs_up_ref', 'list:integer'),
				Field('thumbs_down_ref', 'list:integer')
)

db.post.id.readable = False

db.post.thumbs_up_count.default = 0
db.post.thumbs_down_count.default = 0

db.post.thumbs_up_ref.default = []
db.post.thumbs_down_ref.default = []

db.post.user_id.default = auth.user_id
db.post.user_id.writable = False
db.post.user_id.readable = False

db.post.author.default = get_first_name()
db.post.author.writable = False

db.post.post_time.default = datetime.utcnow()
db.post.post_time.writable = False


# after defining tables, uncomment below to enable auditing
# auth.enable_record_versioning(db)
