# -*- coding: utf-8 -*-
# this file is released under public domain and you can use without limitations

# -------------------------------------------------------------------------
# This is a sample controller
# - index is the default action of any application
# - user is required for authentication and authorization
# - download is for downloading files uploaded in the db (does streaming)
# -------------------------------------------------------------------------
import json

def index():
	"""
	example action using the internationalization operator T and flash
	rendered by views/default/index.html or views/generic.html
	
	if you need a simple wiki simply replace the two lines below with:
	return auth.wiki()
	"""
	user_id = auth.user_id
	if user_id == None:
		response.flash = T("CMPS-183 HW3, not logged in")
	else:
		response.flash = T("CMPS-183 HW3, you're logged in")
	
	all_posts = db().select(db.post.ALL, orderby=db.post.id)
	postCount = 0
	postList = []
	for each_post in all_posts:
		if postCount >= 30:
			break
		postList.append({'post_id':each_post.id,
						'contents':each_post.contents,
						'thumbs_up_count':each_post.thumbs_up_count,
						'thumbs_down_count':each_post.thumbs_down_count,
						'is_thumbs_up': (user_id in each_post.thumbs_up_ref),
						'is_thumbs_down': (user_id in each_post.thumbs_down_ref),
		})
		postCount+=1
	
	
	return dict(message=T(u'Welcome to web2py!'), 
				postURL = URL('default', 'new_post'),
				thumbURL = URL('default', 'thumb'),
				postToLoad = T(json.dumps(postList)),
				postCount = postCount
				)


def user():
    """
    exposes:
    http://..../[app]/default/user/login
    http://..../[app]/default/user/logout
    http://..../[app]/default/user/register
    http://..../[app]/default/user/profile
    http://..../[app]/default/user/retrieve_password
    http://..../[app]/default/user/change_password
    http://..../[app]/default/user/bulk_register
    use @auth.requires_login()
        @auth.requires_membership('group name')
        @auth.requires_permission('read','table name',record_id)
    to decorate functions that need access control
    also notice there is http://..../[app]/appadmin/manage/auth to allow administrator to manage users
    """
    return dict(form=auth())


@cache.action()
def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    return response.download(request, db)


def call():
    """
    exposes services. for example:
    http://..../[app]/default/call/jsonrpc
    decorate with @services.jsonrpc the functions to expose
    supports xml, json, xmlrpc, jsonrpc, amfrpc, rss, csv
    """
    return service()



@auth.requires_login()
def thumb():
	
	thumb = request.vars['thumb']
	if thumb not in ['up', 'down']:
		return
	user_id = auth.user_id
	post_id = int(request.vars['post_id'])
	
	rows = db(db.post.id == post_id).select()
	if len(rows) != 1:
		return
	
	
	newDict = {}
	newDict.update({'post_id':post_id})
	newDict.update({'thumb':thumb})
	newDict.update({'user_id':user_id})
	newDict.update({'length':len(rows)})
	
	
	for post in rows:
		newThUpList = post.thumbs_up_ref
		newThDnList = post.thumbs_down_ref
		newThUpCt = post.thumbs_up_count
		newThDnCt = post.thumbs_down_count
		
		if (thumb == 'up'):
			if (user_id in newThUpList):
				newThUpList.remove(user_id)
				newThUpCt -= 1;
			else:
				newThUpList.append(user_id)
				newThUpCt += 1;
			
			if (user_id in newThDnList) :
				newThDnList.remove(user_id)
				newThDnCt -= 1;
		elif (thumb == 'down'):
			if (user_id in newThDnList):
				newThDnList.remove(user_id)
				newThDnCt -= 1;
			else:
				newThDnList.append(user_id)
				newThDnCt += 1;
			
			if (user_id in newThUpList) :
				newThUpList.remove(user_id)
				newThUpCt -= 1;
				
		db(db.post.id == post_id).update(thumbs_up_ref = newThUpList,
					thumbs_down_ref = newThDnList,
					thumbs_up_count = newThUpCt,
					thumbs_down_count = newThDnCt,
		)
		
		newDict.update({'newThUpCt':newThUpCt})
		newDict.update({'newThUpList':newThUpList})
		newDict.update({'newThDnCt':newThDnCt})
		newDict.update({'newThDnList':newThDnList})
		
		return json.dumps(newDict)
		
		#return {'status': 'success'}
	

@auth.requires_login()
def test():
	
	#redirect(URL('default', 'user'))
	#return HTTP(405)
	#return redirect("https://www.google.com")
	#return request.env.request_method
	newDict ={}
	newDict.update({'post_id':request.vars['post_id']})
	newDict.update({'thumb':request.vars['thumb']})
	return json.dumps(newDict)
	#return response.json(newDict)
	

@auth.requires_login()
def new_post():

	try:
		contents = request.vars['contents'];
	except:
		redirect(URL('default', 'index'))
	else:
		pass
	
	db.post.update_or_insert(contents=contents)
	redirect(URL('default', 'index'))
	